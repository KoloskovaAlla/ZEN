import { useState, useEffect } from 'react'

const Users = () => {
  const [type, setType] = useState('nothing')

  useEffect(() => {
    console.log('изменился type на ',type)
  }, [type])

  const handleUserClick = () => {
    setType('users')
  }
  const handleTodoClick = () => {
    setType('toDo')
  }
  const handlePostsClick = () => {
    setType('posts')
  }
  
  return (
    <div>
      <h1>Ресурс: {type}</h1>
      <button onClick={handleUserClick}>Пользователи</button>
      <button onClick={handleTodoClick}>Сделать</button>
      <button onClick={handlePostsClick}>Посты</button>
    </div>
  )  
}

export default Users