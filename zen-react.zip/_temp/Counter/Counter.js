import Title from '../../Title'

import { useState } from 'react'

export const Counter = ({ initialValue, maxValue, minValue }) => {
  const [countValue, setCountValue] = useState(initialValue ? initialValue : 0 )  
  
  // const handleIncrementClick = () => {
  //   if (countValue < maxValue) {
  //     setCountValue(countValue + 1)
  //   }     
  // }

  const handleIncrementClick = () => {
    setCountValue((currentValue) => {
      return currentValue < maxValue ? ++currentValue : currentValue
    })
  }

  // const handleDecrementClick = () => {    
  //   if (countValue > minValue) {      
  //     setCountValue(countValue - 1)     
  //   } 
  // }  

  const handleDecrementClick = () => {
    setCountValue((currentValue) => {
      return currentValue > minValue ? --currentValue : currentValue
    })
  }

  const handleResetClick = () => {
    setCountValue(initialValue ? initialValue : 0)  
  } 

  return (
    <div className='counter'>
      <Title 
        priority={2} 
        className='title'       
      >
        Counter: {countValue}
      </Title>
      <button onClick={handleIncrementClick} disabled={countValue === maxValue}>+</button>
      <button onClick={handleDecrementClick} disabled={countValue === minValue}>-</button>
      <button onClick={handleResetClick}>RESET</button>
    </div>
  )
}

// export default Counter