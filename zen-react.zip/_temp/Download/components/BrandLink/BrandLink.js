import { ReactComponent as AppleIcon } from './assets/btn-apple.svg'
import { ReactComponent as GoogleIcon } from './assets/btn-google.svg'

const BrandLink = ({ parentClassName, link}) => {  
  const className = parentClassName
    ? `${parentClassName}__link`
    : 'link'
  
  return (
    <li className={className}>
      <a href={link.url && link.url}>
        {link.name === 'apple' 
          ? <AppleIcon /> 
          : <GoogleIcon />
        }
      </a>
    </li>
  )
}

export default BrandLink
