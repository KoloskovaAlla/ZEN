import Title from '../../common/Title/Title'
import Text from '../../common/Text/Text'
import Image from '../../common/Image/Image'
import BrandLink from './components/BrandLink/BrandLink'

/**
 * @param {Object} data 
 * @returns {string}
 */

const Download = ({data}) => {
  if (!Object.keys(data).length) return ''

  const className = 'download'
  
  return (
    <section className={className}>   
      <div className={`${className}__wrapper`}>
        <div className={`${className}__body`}>          
          {data.title && <Title priority={data.title.priority} parentClassName={className} children={data.title.content} />}        
   
          {data.texts?.length > 0 &&
            data.texts.map((text, index) => <Text text={text} parentClassName={className} key={`${index}`} />)
          }     
      
          <ul className={`${className}__links`}>             
            {data.links?.length > 0 && 
              data.links.map((link, index) => <BrandLink parentClassName={className} link={link} key={`${index}`} />)
            }           
          </ul>
        </div>

        {data.image && <Image parentClassName={className} imageData={data.image} />}
      </div>
    </section>
  )
}

export default Download

//id='${data.name}'