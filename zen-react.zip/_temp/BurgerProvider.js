import BurgerContext from './BurgerContext'
import { useState } from 'react'

const BurgerProvider = ({ children }) => {
  const [burgerClicked, setBurgerClicked] = useState(false)

  const handleBurgerClick = () => {
    burgerClicked ? setBurgerClicked(false) : setBurgerClicked(true)
  }

  const value = {
    burgerClicked,
    setBurgerClicked,
    handleBurgerClick
  }

  return (
    <BurgerContext.Provider value={value}>
      {children}
    </BurgerContext.Provider>
  )
}

export default BurgerProvider