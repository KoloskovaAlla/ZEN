import {createContext} from 'react'

const BurgerContext = createContext()

export default BurgerContext