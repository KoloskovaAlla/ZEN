import {createContext} from 'react'

const SliderContext = createContext()

export default SliderContext