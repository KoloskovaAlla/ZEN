import {createContext} from 'react'

const LangContext = createContext()

export default LangContext