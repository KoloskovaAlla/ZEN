import {createContext} from 'react'

const PreviewContext = createContext()

export default PreviewContext