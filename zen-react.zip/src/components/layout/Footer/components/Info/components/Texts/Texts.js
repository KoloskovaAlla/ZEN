const Texts = () => {
 return (
  <div>Texts</div>
 )
}

export default Texts